import pandas as pd 
import os


#C:\Users\nprogal\Desktop\Business Analytics.zip\Business Analytics
cwd=os.getcwd()


test_set = pd.read_csv(r'test_set.csv')
test_set = pd.read_csv(r'test_set.csv')





